@echo off
setlocal
cd /d "%~dp0"
title AERO - Smart Environmental Risk Prediction

echo.
echo ==========================================================
echo  AERO - SMART ENVIRONMENTAL RISK PREDICTION AND ANALYTICS
echo ==========================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [1/4] Creating a project virtual environment using standard Python 3.13...
    py -3.13 -m venv .venv
    if errorlevel 1 (
        echo Python 3.13 was not found. Trying the default Python installation...
        py -3 -m venv .venv
    )
    if errorlevel 1 (
        echo.
        echo ERROR: Could not create the virtual environment.
        echo Install standard Python 3.13 from python.org, then try again.
        pause
        exit /b 1
    )
) else (
    echo [1/4] Project virtual environment found.
)

echo.
echo [2/4] Updating pip build tools...
".venv\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 (
    echo WARNING: Could not update all build tools. Continuing to dependency installation...
)

echo.
echo [3/4] Installing backend and machine-learning dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: Dependency installation failed.
    echo Check the first error above and ensure your internet connection is available.
    pause
    exit /b 1
)

echo.
echo [4/4] Starting the local web application...
echo.
echo Open this address in Chrome or Edge: http://127.0.0.1:8000
echo API documentation: http://127.0.0.1:8000/api/docs
echo To stop the server, press CTRL+C in this window.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
if errorlevel 1 (
    echo.
    echo The web server stopped with an error. Review the traceback above.
    pause
)
endlocal
