# Data source and attribution

The file `raw/archive (1).zip` was included from the project owner's previously supplied dataset and contains `aqi.csv`.

Before redistributing this repository publicly, add the exact original source URL, publisher, download date, and license/attribution terms from the original download page. Do not assume that all content on a public data portal has identical reuse terms.

The application's last available observation date is read from the data at startup. In the currently supplied archive it is 2025-04-30. This application is a historical analytics and experimental forecasting demo; it is not a live AQI feed.
