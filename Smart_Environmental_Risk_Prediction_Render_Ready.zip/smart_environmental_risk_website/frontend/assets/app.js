'use strict';

const state = {
  view: 'overview',
  area: 'Ahmedabad',
  region: 'Gujarat',
  days: 365,
  theme: 'dark',
  summary: null,
  apiHealthy: false,
  areas: [],
  lastModel: null,
  lastForecast: null,
};

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const icons = {
  download: '↓', external: '↗', refresh: '⟳', filter: '☷', search: '⌕', calendar: '▦', arrow: '→',
  trend: '⌁', location: '⌖', warning: '⚠', wave: '∿', grid: '▦', chart: '▥', check: '✓', info: 'i',
  database: '▤', spark: '✳', target: '◎', brain: '⌘', leaf: '❋', clock: '◷', pin: '⌖'
};

const fmtNum = (n, digits = 0) => n == null || Number.isNaN(Number(n)) ? '—' : Number(n).toLocaleString('en-IN', { maximumFractionDigits: digits, minimumFractionDigits: digits });
const fmtDate = (iso, opts = { day: '2-digit', month: 'short', year: 'numeric' }) => {
  if (!iso) return '—';
  const d = new Date(`${iso}T00:00:00`);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString('en-IN', opts);
};
const aqiTone = (value) => value <= 50 ? 'green' : value <= 100 ? 'lime' : value <= 200 ? 'amber' : value <= 300 ? 'orange' : value <= 400 ? 'red' : 'violet';
const aqiLabel = (value) => value <= 50 ? 'Good' : value <= 100 ? 'Satisfactory' : value <= 200 ? 'Moderate' : value <= 300 ? 'Poor' : value <= 400 ? 'Very Poor' : 'Severe';
const toneColor = (value) => value <= 50 ? '#75dfae' : value <= 100 ? '#c8df91' : value <= 200 ? '#ffc56b' : value <= 300 ? '#ffac7f' : value <= 400 ? '#ff7b88' : '#c5a9ff';
const badge = (label, tone = 'muted') => `<span class="badge ${tone}">${escapeHtml(label)}</span>`;
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const areaArgs = () => `area=${encodeURIComponent(state.area)}&state=${encodeURIComponent(state.region)}`;

async function api(path, options = {}) {
  const response = await fetch(path, { headers: { 'Accept': 'application/json', ...(options.headers || {}) }, ...options });
  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) {
    const message = payload && typeof payload === 'object' ? payload.detail || payload.message || response.statusText : payload || response.statusText;
    throw new Error(message);
  }
  return payload;
}

function toast(message, type = 'success') {
  const host = $('#toast-stack');
  if (!host) return;
  const node = document.createElement('div');
  node.className = `toast ${type}`;
  node.textContent = message;
  host.appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

function setPageTitle(title) {
  $('#crumb-current').textContent = title.toUpperCase();
  document.title = `${title} | Atmosphere Intelligence`;
  $$('.nav-item').forEach((node) => node.classList.toggle('active', node.dataset.view === state.view));
}

function setPipeline(healthy, health = {}) {
  const status = $('#pipeline-status');
  const detail = $('#pipeline-detail');
  const meter = $('#pipeline-meter-fill');
  if (!status) return;
  state.apiHealthy = healthy;
  status.textContent = healthy ? 'All systems operational' : 'API unavailable';
  status.style.color = healthy ? 'var(--green)' : 'var(--red)';
  detail.textContent = healthy ? `${fmtNum(health.rows)} source records indexed` : 'Start backend using run_windows.bat';
  meter.style.width = healthy ? '100%' : '20%';
  $('#dataset-last-date').textContent = health.data_end ? fmtDate(health.data_end) : 'unavailable';
}

async function initialize() {
  const theme = localStorage.getItem('aero-theme');
  if (theme === 'light') document.body.classList.add('light-theme');
  try {
    const [health, areas] = await Promise.all([api('/api/health'), api('/api/areas')]);
    if (health.status !== 'ok') throw new Error(health.message || 'Backend unavailable');
    state.areas = areas.areas || [];
    setPipeline(true, health);
    populateAreaSelect();
    await navigate('overview');
    const alerts = await api('/api/alerts?limit=50');
    $('#alert-count').textContent = alerts.count > 9 ? '9+' : alerts.count;
  } catch (error) {
    setPipeline(false);
    $('#app-view').innerHTML = `<div class="error-state panel"><div class="empty-icon">⚠</div><b>Backend connection unavailable</b><p>${escapeHtml(error.message)}<br>Run <code>run_windows.bat</code> from the project folder, then refresh this page.</p><button class="button primary" id="retry-connect">Retry connection</button></div>`;
    $('#retry-connect')?.addEventListener('click', initialize);
    toast('Unable to reach the local API. Check that the backend is running.', 'error');
  }
}

function populateAreaSelect() {
  const select = $('#global-area');
  if (!select) return;
  const keys = state.areas.map((x) => `<option value="${escapeHtml(x.key)}" ${x.area === state.area && x.state === state.region ? 'selected' : ''}>${escapeHtml(x.area)} · ${escapeHtml(x.state)}</option>`).join('');
  select.innerHTML = keys;
  if (!state.areas.some((x) => x.area === state.area && x.state === state.region)) {
    const fallback = state.areas.find((x) => x.area === 'Ahmedabad' && x.state === 'Gujarat') || state.areas[0];
    if (fallback) { state.area = fallback.area; state.region = fallback.state; select.value = fallback.key; }
  }
}

async function navigate(view) {
  state.view = view;
  const titles = { overview: 'Overview', forecast: 'Forecast lab', regions: 'Regional explorer', models: 'Model bench', quality: 'Data quality', project: 'Project brief' };
  setPageTitle(titles[view] || 'Overview');
  const app = $('#app-view');
  app.innerHTML = '<div class="loading-screen"><div class="loader-ring"></div><p>Loading analytical workspace…</p></div>';
  try {
    if (view === 'overview') await renderOverview();
    else if (view === 'forecast') renderForecastPage();
    else if (view === 'regions') await renderRegionsPage();
    else if (view === 'models') await renderModelsPage();
    else if (view === 'quality') await renderQualityPage();
    else renderProjectPage();
  } catch (error) {
    app.innerHTML = `<div class="panel error-state"><div class="empty-icon">⚠</div><b>We couldn't load this view</b><p>${escapeHtml(error.message)}</p><button class="button" id="retry-view">Try again</button></div>`;
    $('#retry-view')?.addEventListener('click', () => navigate(state.view));
  }
}

function pageHeader(kicker, title, subtitle, actions = '') {
  return `<div class="page-header"><div><div class="section-kicker">${kicker}</div><h1>${title}</h1><p>${subtitle}</p></div><div class="header-actions">${actions}</div></div>`;
}

function downloadButton() {
  return `<a class="button" href="/api/export?${areaArgs()}" download><span class="button-icon">↓</span> Export CSV</a>`;
}

async function renderOverview() {
  const app = $('#app-view');
  app.innerHTML = pageHeader('ENVIRONMENTAL INTELLIGENCE / 01', 'Air quality, made actionable.', 'Explore historic AQI patterns, compare regional observations, and review an experimental forecast built on your dataset.', `${downloadButton()}<button class="button primary" id="open-forecast"><span class="button-icon">⌁</span> Open forecast lab</button>`)
    + `<div class="kpi-grid" id="overview-kpis"><div class="kpi-card"><div class="skeleton" style="width:100px"></div><div class="skeleton" style="width:90px;height:28px;margin-top:20px"></div></div><div class="kpi-card"><div class="skeleton" style="width:100px"></div><div class="skeleton" style="width:90px;height:28px;margin-top:20px"></div></div><div class="kpi-card"><div class="skeleton" style="width:100px"></div><div class="skeleton" style="width:90px;height:28px;margin-top:20px"></div></div><div class="kpi-card"><div class="skeleton" style="width:100px"></div><div class="skeleton" style="width:90px;height:28px;margin-top:20px"></div></div></div>
    <div class="content-grid"><section class="panel"><div class="panel-header"><div><div class="panel-title">AQI trajectory</div><div class="panel-subtitle" id="timeline-subtitle">Daily observations from the selected area</div></div><div class="panel-actions" id="range-actions"><button class="range-button" data-days="30">30D</button><button class="range-button" data-days="90">90D</button><button class="range-button active" data-days="365">1Y</button><button class="range-button" data-days="0">ALL</button></div></div><div class="chart-wrap"><canvas class="chart-canvas" id="history-chart" aria-label="Historical AQI line chart"></canvas></div><div class="chart-legend"><span><i class="legend-mark"></i> Daily AQI</span><span><i class="legend-mark band"></i> Observed range</span><span class="muted">Shaded region is a visual aid, not a confidence interval.</span></div></section>
      <section class="panel"><div class="panel-header"><div><div class="panel-title">Current selected observation</div><div class="panel-subtitle">Latest record available in the source data</div></div><span class="badge muted" id="latest-date-badge">—</span></div><div class="risk-panel"><div class="risk-gauge-area"><div class="gauge"><svg viewBox="0 0 140 140" aria-hidden="true"><circle class="gauge-track" cx="70" cy="70" r="55" pathLength="251"/><circle class="gauge-value-arc" id="gauge-arc" cx="70" cy="70" r="55" pathLength="251"/></svg><div class="gauge-center"><div class="gauge-number" id="gauge-number">—</div><div class="gauge-label">AQI INDEX</div></div></div><div class="risk-copy"><span class="risk-badge" id="risk-badge">Loading category</span><h3 id="risk-title">Loading observation</h3><p id="risk-copy">We are retrieving the selected area's latest AQI record.</p></div></div><div class="risk-scale"><span></span><span></span><span></span><span></span><span></span><span></span></div><div class="risk-meta"><div><span>Dominant pollutants</span><b id="pollutants-value">—</b></div><div><span>Monitoring stations</span><b id="stations-value">—</b></div></div></div></section></div>
    <div class="two-panels"><section class="panel"><div class="panel-header"><div><div class="panel-title">Monthly AQI signal</div><div class="panel-subtitle">Mean daily index by calendar month</div></div><span class="badge muted">MONTHLY AGGREGATE</span></div><div class="bar-chart-wrap"><canvas class="chart-canvas" id="monthly-chart" aria-label="Monthly mean AQI bar chart"></canvas></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Observation distribution</div><div class="panel-subtitle">Count of records by AQI band</div></div><span class="badge muted">FULL AREA HISTORY</span></div><div class="panel-body"><div class="category-stack" id="category-stack"><div class="skeleton" style="width:100%;height:12px"></div></div><hr class="section-divider"><div class="insight-card" style="padding:11px"><b>Reading the categories</b><p>Numeric bands follow common Indian AQI ranges. Source labels may vary; the Data Quality page flags inconsistencies.</p></div></div></section></div>
    <div class="split-heading"><h2>Regional watch</h2><span>Latest available observations · source data through <b id="watch-date">—</b></span></div>
    <section class="panel"><div class="panel-header"><div><div class="panel-title">Areas needing a closer look</div><div class="panel-subtitle">Highest latest AQI observations across included areas</div></div><button class="button small-button" id="see-regions">Explore all regions <span>→</span></button></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Area</th><th>State / UT</th><th>Latest AQI</th><th>Band</th><th>Observation date</th></tr></thead><tbody id="watch-table"><tr><td colspan="5" class="muted">Loading regional observations…</td></tr></tbody></table></div></section>
    <div class="split-heading"><h2>Research notes</h2><span>Interpretation, not diagnosis</span></div><div class="insight-grid"><div class="insight-card"><div class="insight-icon">⌁</div><b>Patterns over single points</b><p>Use the time series and monthly summaries to understand variation. One daily value cannot explain an area's full exposure pattern.</p></div><div class="insight-card"><div class="insight-icon">◎</div><b>Compare comparable periods</b><p>Regional rankings use each area's latest available row; dates may differ. Check the date column before drawing a comparison.</p></div><div class="insight-card"><div class="insight-icon">✳</div><b>Forecasts need validation</b><p>Model output is experimental and based on historical AQI lags. Weather, emissions and future events aren't included in this dataset.</p></div></div>`;
  $('#open-forecast').addEventListener('click', () => navigate('forecast'));
  $('#see-regions').addEventListener('click', () => navigate('regions'));
  $$('#range-actions button').forEach((button) => button.addEventListener('click', async () => {
    state.days = Number(button.dataset.days);
    $$('#range-actions button').forEach((b) => b.classList.toggle('active', b === button));
    const hist = await api(`/api/history?${areaArgs()}&days=${state.days}`);
    drawLineChart($('#history-chart'), hist.records, { color: '#62e3cb' });
    $('#timeline-subtitle').textContent = `${hist.count.toLocaleString()} daily observations · ${fmtDate(hist.records[0]?.date)} – ${fmtDate(hist.last_date)}`;
  }));
  const [summary, history, regions] = await Promise.all([
    api(`/api/summary?${areaArgs()}`), api(`/api/history?${areaArgs()}&days=${state.days}`), api('/api/regions?sort=highest&limit=6')
  ]);
  state.summary = summary;
  renderOverviewKpis(summary);
  $('#latest-date-badge').textContent = fmtDate(summary.latest.date);
  $('#gauge-number').textContent = fmtNum(summary.latest.aqi);
  $('#gauge-arc').style.stroke = toneColor(summary.latest.aqi);
  $('#gauge-arc').style.strokeDasharray = `${Math.min(188, Math.max(2, summary.latest.aqi / 500 * 188))} 251`;
  $('#risk-badge').className = `risk-badge ${aqiTone(summary.latest.aqi)}`;
  $('#risk-badge').textContent = `${summary.latest.category.toUpperCase()} · ${summary.latest.aqi <= 100 ? 'LOWER BAND' : summary.latest.aqi <= 200 ? 'MODERATE BAND' : 'ELEVATED BAND'}`;
  $('#risk-title').textContent = summary.latest.category === 'Good' || summary.latest.category === 'Satisfactory' ? 'Lower observed AQI band' : summary.latest.category === 'Moderate' ? 'Moderate AQI band' : 'Elevated AQI band';
  $('#risk-copy').textContent = `The selected dataset's most recent ${summary.area} record was ${summary.latest.aqi} on ${fmtDate(summary.latest.date)}. This is historical data, not a real-time exposure advisory.`;
  $('#pollutants-value').textContent = summary.latest.pollutants || 'Not reported';
  $('#stations-value').textContent = summary.latest.stations == null ? 'Not reported' : fmtNum(summary.latest.stations);
  $('#watch-date').textContent = fmtDate(regions.as_of);
  $('#watch-table').innerHTML = regions.regions.slice(0, 6).map((r) => `<tr><td class="table-area">${escapeHtml(r.area)}</td><td>${escapeHtml(r.state)}</td><td class="mono">${fmtNum(r.aqi)}</td><td>${badge(r.category, aqiTone(r.aqi))}</td><td>${fmtDate(r.date)}</td></tr>`).join('');
  $('#timeline-subtitle').textContent = `${history.count.toLocaleString()} daily observations · ${fmtDate(history.records[0]?.date)} – ${fmtDate(history.last_date)}`;
  drawLineChart($('#history-chart'), history.records, { color: '#62e3cb' });
  drawBarChart($('#monthly-chart'), summary.monthly.slice(-12));
  renderCategoryStack(summary.status_distribution);
}

function renderOverviewKpis(s) {
  const latestDelta = s.last_30_day_change;
  $('#overview-kpis').innerHTML = `
    <div class="kpi-card" style="--glow:rgba(98,227,203,.08);--icon-bg:rgba(98,227,203,.1);--icon-color:var(--teal)"><div class="kpi-top"><span>Latest observed AQI</span><span class="kpi-icon">⌁</span></div><div class="kpi-value-row"><span class="kpi-value">${fmtNum(s.latest.aqi)}</span><span class="kpi-unit">INDEX</span></div><div class="kpi-foot">${badge(s.latest.category, aqiTone(s.latest.aqi))}<span>· ${fmtDate(s.latest.date)}</span></div></div>
    <div class="kpi-card" style="--glow:rgba(124,174,255,.08);--icon-bg:rgba(124,174,255,.1);--icon-color:var(--blue)"><div class="kpi-top"><span>Historical mean</span><span class="kpi-icon">∿</span></div><div class="kpi-value-row"><span class="kpi-value">${fmtNum(s.mean_aqi, 1)}</span><span class="kpi-unit">AQI</span></div><div class="kpi-foot"><span class="trend-neutral">●</span><span>Across ${fmtNum(s.observations)} observations</span></div></div>
    <div class="kpi-card" style="--glow:rgba(255,197,107,.08);--icon-bg:rgba(255,197,107,.1);--icon-color:var(--amber)"><div class="kpi-top"><span>Observed peak</span><span class="kpi-icon">↗</span></div><div class="kpi-value-row"><span class="kpi-value">${fmtNum(s.max_aqi)}</span><span class="kpi-unit">AQI</span></div><div class="kpi-foot"><span class="trend-warn">●</span><span>Maximum in available history</span></div></div>
    <div class="kpi-card" style="--glow:rgba(197,169,255,.08);--icon-bg:rgba(197,169,255,.1);--icon-color:var(--violet)"><div class="kpi-top"><span>Data coverage</span><span class="kpi-icon">▦</span></div><div class="kpi-value-row"><span class="kpi-value">${fmtNum(s.observations)}</span><span class="kpi-unit">DAYS</span></div><div class="kpi-foot"><span class="trend-neutral">⌑</span><span>${fmtDate(s.period_start)} – ${fmtDate(s.period_end)}</span></div></div>`;
}

function renderCategoryStack(distribution) {
  const order = ['Good', 'Satisfactory', 'Moderate', 'Poor', 'Very Poor', 'Severe'];
  const total = Object.values(distribution || {}).reduce((a, b) => a + b, 0) || 1;
  $('#category-stack').innerHTML = order.map((name) => {
    const count = Number(distribution?.[name] || 0);
    const color = toneColor(({ Good: 25, Satisfactory: 75, Moderate: 150, Poor: 250, 'Very Poor': 350, Severe: 450 })[name]);
    return `<div class="category-row"><span class="category-name">${name}</span><div class="category-bar"><div class="category-fill" style="width:${count / total * 100}%;background:${color}"></div></div><span class="category-count">${fmtNum(count)}</span></div>`;
  }).join('');
}

function drawLineChart(canvas, records, options = {}) {
  if (!canvas) return;
  const ctx = setupCanvas(canvas);
  if (!ctx) return;
  const width = canvas.width, height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  const dpr = window.devicePixelRatio || 1;
  const pad = { left: 38 * dpr, right: 15 * dpr, top: 12 * dpr, bottom: 28 * dpr };
  const points = (records || []).filter((r) => Number.isFinite(Number(r.aqi)) && r.date);
  if (points.length < 2) return drawEmptyChart(ctx, width, height, dpr, 'Not enough observations to draw this chart');
  const values = points.map((r) => Number(r.aqi));
  const rawMin = Math.min(...values), rawMax = Math.max(...values);
  const min = Math.max(0, Math.floor((rawMin - 15) / 25) * 25);
  const max = Math.min(500, Math.ceil((rawMax + 15) / 25) * 25 || 100);
  const plotW = width - pad.left - pad.right, plotH = height - pad.top - pad.bottom;
  const x = (i) => pad.left + (i / (points.length - 1)) * plotW;
  const y = (v) => pad.top + (1 - (v - min) / Math.max(1, max - min)) * plotH;
  ctx.font = `${10 * dpr}px ui-monospace, Menlo, monospace`;
  ctx.textBaseline = 'middle';
  for (let i = 0; i <= 4; i++) {
    const val = min + (max - min) * i / 4;
    const yy = y(val);
    ctx.beginPath(); ctx.moveTo(pad.left, yy); ctx.lineTo(width - pad.right, yy);
    ctx.strokeStyle = 'rgba(109,134,163,.14)'; ctx.lineWidth = 1 * dpr; ctx.stroke();
    ctx.fillStyle = '#70859e'; ctx.textAlign = 'right'; ctx.fillText(String(Math.round(max - (max - min) * i / 4)), pad.left - 8 * dpr, yy);
  }
  const grad = ctx.createLinearGradient(0, pad.top, 0, height - pad.bottom);
  grad.addColorStop(0, 'rgba(98,227,203,.20)'); grad.addColorStop(1, 'rgba(98,227,203,.005)');
  ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(x(i), y(Number(p.aqi))) : ctx.moveTo(x(i), y(Number(p.aqi))));
  ctx.lineTo(x(points.length - 1), height - pad.bottom); ctx.lineTo(x(0), height - pad.bottom); ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
  ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(x(i), y(Number(p.aqi))) : ctx.moveTo(x(i), y(Number(p.aqi))));
  ctx.lineWidth = 2.2 * dpr; ctx.strokeStyle = options.color || '#62e3cb'; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
  const step = Math.max(1, Math.floor((points.length - 1) / 5));
  points.forEach((p, i) => { if (i % step === 0 || i === points.length - 1) { ctx.fillStyle = '#8195ae'; ctx.textAlign = 'center'; ctx.fillText(shortDate(p.date), x(i), height - 10 * dpr); } });
  const last = points[points.length - 1];
  ctx.beginPath(); ctx.arc(x(points.length - 1), y(Number(last.aqi)), 4 * dpr, 0, Math.PI * 2); ctx.fillStyle = options.color || '#62e3cb'; ctx.fill();
  canvas.title = points.map((p) => `${p.date}: AQI ${p.aqi}`).join('\n');
}

function drawForecastChart(canvas, history, forecast) {
  if (!canvas) return;
  const ctx = setupCanvas(canvas), dpr = window.devicePixelRatio || 1;
  if (!ctx) return;
  const width = canvas.width, height = canvas.height; ctx.clearRect(0, 0, width, height);
  const past = (history || []).filter((r) => Number.isFinite(Number(r.aqi))).slice(-60);
  const future = forecast || [];
  const combined = [...past.map((r) => ({ date: r.date, value: Number(r.aqi), kind: 'actual' })), ...future.map((r) => ({ date: r.date, value: Number(r.predicted_aqi), low: Number(r.lower_estimate), high: Number(r.upper_estimate), kind: 'forecast' }))];
  if (combined.length < 2) return drawEmptyChart(ctx, width, height, dpr, 'Forecast chart unavailable');
  const values = combined.map((r) => r.value).concat(future.flatMap((r) => [Number(r.lower_estimate), Number(r.upper_estimate)]));
  const min = Math.max(0, Math.floor((Math.min(...values) - 15) / 25) * 25), max = Math.min(500, Math.ceil((Math.max(...values) + 15) / 25) * 25);
  const pad = { left: 40 * dpr, right: 14 * dpr, top: 13 * dpr, bottom: 30 * dpr }, plotW = width - pad.left - pad.right, plotH = height - pad.top - pad.bottom;
  const x = i => pad.left + i / Math.max(1, combined.length - 1) * plotW, y = v => pad.top + (1 - (v - min) / Math.max(1, max - min)) * plotH;
  ctx.font = `${10*dpr}px ui-monospace, Menlo, monospace`; ctx.textBaseline = 'middle'; ctx.textAlign = 'right';
  for (let i = 0; i <= 4; i++) { const v = min + (max-min)*i/4, yy = y(v); ctx.beginPath(); ctx.moveTo(pad.left,yy); ctx.lineTo(width-pad.right,yy); ctx.strokeStyle='rgba(109,134,163,.14)'; ctx.stroke(); ctx.fillStyle='#70859e'; ctx.fillText(String(Math.round(max-(max-min)*i/4)),pad.left-8*dpr,yy); }
  if (future.length) {
    ctx.beginPath(); future.forEach((r,i)=>{const ix=past.length+i; i===0?ctx.moveTo(x(ix),y(Number(r.upper_estimate))):ctx.lineTo(x(ix),y(Number(r.upper_estimate)));});
    [...future].reverse().forEach((r,i)=>ctx.lineTo(x(past.length+future.length-1-i),y(Number(r.lower_estimate)))); ctx.closePath(); ctx.fillStyle='rgba(255,197,107,.10)'; ctx.fill();
  }
  ctx.beginPath(); past.forEach((r,i)=>i?ctx.lineTo(x(i),y(Number(r.aqi))):ctx.moveTo(x(i),y(Number(r.aqi)))); ctx.lineWidth=2*dpr; ctx.strokeStyle='#62e3cb'; ctx.lineCap='round'; ctx.lineJoin='round'; ctx.stroke();
  if (future.length) { ctx.beginPath(); future.forEach((r,i)=>{const ix=past.length+i; i===0?ctx.moveTo(x(ix),y(Number(r.predicted_aqi))):ctx.lineTo(x(ix),y(Number(r.predicted_aqi)));}); ctx.strokeStyle='#ffc56b'; ctx.lineWidth=2.2*dpr; ctx.setLineDash([5*dpr,4*dpr]); ctx.stroke(); ctx.setLineDash([]); }
  const tickIndices = [0,Math.floor(combined.length*.25),Math.floor(combined.length*.5),Math.floor(combined.length*.75),combined.length-1];
  tickIndices.forEach(i=>{ctx.fillStyle='#70859e';ctx.textAlign='center';ctx.fillText(shortDate(combined[i].date),x(i),height-11*dpr)});
  canvas.title = combined.map(p=>`${p.date}: AQI ${p.value}`).join('\n');
}

function drawBarChart(canvas, monthly) {
  if (!canvas) return;
  const ctx = setupCanvas(canvas), dpr = window.devicePixelRatio || 1;
  if (!ctx) return;
  const width = canvas.width, height = canvas.height; ctx.clearRect(0,0,width,height);
  const data = (monthly || []).slice(-12);
  if (!data.length) return drawEmptyChart(ctx,width,height,dpr,'Monthly summary unavailable');
  const pad={left:35*dpr,right:12*dpr,top:12*dpr,bottom:29*dpr},plotW=width-pad.left-pad.right,plotH=height-pad.top-pad.bottom;
  const max=Math.max(150,Math.ceil(Math.max(...data.map(d=>Number(d.mean_aqi)||0))/50)*50), gap=5*dpr, barW=Math.max(5*dpr,plotW/data.length-gap);
  ctx.font=`${9*dpr}px ui-monospace, Menlo, monospace`;ctx.textBaseline='middle';ctx.textAlign='right';
  for(let i=0;i<=3;i++){const v=max*i/3,yy=pad.top+plotH-(v/max)*plotH;ctx.beginPath();ctx.moveTo(pad.left,yy);ctx.lineTo(width-pad.right,yy);ctx.strokeStyle='rgba(109,134,163,.14)';ctx.stroke();ctx.fillStyle='#70859e';ctx.fillText(String(Math.round(v)),pad.left-7*dpr,yy)}
  data.forEach((d,i)=>{const value=Number(d.mean_aqi)||0, x=pad.left+i*plotW/data.length+gap/2, h=value/max*plotH, y=pad.top+plotH-h;const grad=ctx.createLinearGradient(0,y,0,y+h);grad.addColorStop(0,'#62e3cb');grad.addColorStop(1,'rgba(65,126,232,.35)');ctx.fillStyle=grad;roundRect(ctx,x,y,barW,h,3*dpr);ctx.fill();if(data.length<=8||i%2===0||i===data.length-1){ctx.fillStyle='#70859e';ctx.textAlign='center';ctx.fillText(String(d.month).slice(2),x+barW/2,height-12*dpr)}});
  canvas.title=data.map(d=>`${d.month}: mean AQI ${d.mean_aqi}`).join('\n');
}

function setupCanvas(canvas) {
  if (!canvas) return null;
  const rect = canvas.getBoundingClientRect(); if (!rect.width || !rect.height) return null;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(rect.width*dpr); canvas.height = Math.floor(rect.height*dpr);
  const ctx = canvas.getContext('2d'); ctx.setTransform(dpr,0,0,dpr,0,0);
  // Most drawing helpers reset to backing-pixel coordinates; return a DPR-aware context below.
  ctx.setTransform(1,0,0,1,0,0);
  return ctx;
}
function drawEmptyChart(ctx,w,h,dpr,message){ctx.clearRect(0,0,w,h);ctx.fillStyle='#7187a1';ctx.font=`${12*dpr}px system-ui`;ctx.textAlign='center';ctx.fillText(message,w/2,h/2)}
function shortDate(iso){const d=new Date(`${iso}T00:00:00`);return Number.isNaN(d.getTime())?iso:d.toLocaleDateString('en-IN',{day:'2-digit',month:'short'}).replace(' ',' ')}
function roundRect(ctx,x,y,w,h,r){const rr=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+rr,y);ctx.arcTo(x+w,y,x+w,y+h,rr);ctx.arcTo(x+w,y+h,x,y+h,rr);ctx.arcTo(x,y+h,x,y,rr);ctx.arcTo(x,y,x+w,y,rr);ctx.closePath()}

function renderForecastPage() {
  const app = $('#app-view');
  app.innerHTML = pageHeader('PREDICTIVE ANALYTICS / 02', 'Forecast lab', 'Run a time-aware next-day AQI forecasting experiment. Models use historical AQI lags; no live weather or emissions feed is connected.', `<span class="badge muted">ML · EXPERIMENTAL</span>`)
  + `<section class="panel"><div class="panel-header"><div><div class="panel-title">Forecast configuration</div><div class="panel-subtitle">Change horizon and a transparent what-if scenario overlay.</div></div><span class="badge amber">NOT A LIVE FORECAST</span></div><div class="panel-body"><div class="forecast-controls"><div class="field"><label>AREA / CITY</label><select id="forecast-area" class="select-control">${areaOptions()}</select></div><div class="field"><label>FORECAST HORIZON</label><select class="select-control" id="forecast-horizon"><option value="1">Next day · 1 day</option><option value="3">Short range · 3 days</option><option value="7" selected>Weekly · 7 days</option><option value="14">Extended · 14 days</option></select></div><div class="slider-field"><div class="slider-top"><span>Scenario adjustment</span><strong id="scenario-label">0%</strong></div><input type="range" id="scenario-adjustment" min="-15" max="15" step="5" value="0"/><div class="muted" style="font-size:9px">User-defined sensitivity overlay, not a weather model.</div></div><button class="button primary" id="run-forecast"><span class="button-icon">✳</span> Run experiment</button></div></div></section>
  <div class="forecast-summary" id="forecast-summary"><div class="forecast-stat"><span>SELECTED MODEL</span><b>Not trained</b><small>Run experiment to train/evaluate</small></div><div class="forecast-stat"><span>TEST MAE</span><b>—</b><small>Held-out chronological test</small></div><div class="forecast-stat"><span>HISTORY ENDS</span><b id="forecast-data-end">—</b><small>Last available source observation</small></div></div>
  <div class="forecast-grid"><section class="panel"><div class="panel-header"><div><div class="panel-title">Observed history → experimental forecast</div><div class="panel-subtitle" id="forecast-chart-subtitle">Run the experiment to render forecast values.</div></div><div class="chart-legend" style="padding:0"><span><i class="legend-mark"></i> Actual AQI</span><span><i class="legend-mark forecast"></i> Forecast</span></div></div><div class="forecast-chart-wrap"><canvas class="chart-canvas" id="forecast-chart"></canvas></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Forecast breakdown</div><div class="panel-subtitle">Point estimate and indicative interval</div></div></div><div class="panel-body" id="forecast-list"><div class="empty-state"><div class="empty-icon">⌁</div><b>Ready when you are</b><p>Select a horizon and run the experiment to compare predicted AQI values.</p></div></div></section></div>
  <div class="split-heading"><h2>How to interpret this output</h2><span>Model transparency</span></div><div class="insight-grid"><div class="insight-card"><div class="insight-icon">⌘</div><b>Model choice is validated</b><p>Ridge, Random Forest, and Gradient Boosting are compared using a validation period. The lowest validation MAE selects the production model.</p></div><div class="insight-card"><div class="insight-icon">▥</div><b>Test set stays separate</b><p>Model results are reported on a later chronological holdout. This gives a more realistic estimate than a shuffled random split.</p></div><div class="insight-card"><div class="insight-icon">⚠</div><b>Uncertainty is approximate</b><p>The interval is based on validation residuals and grows with horizon. It is indicative, not a guaranteed prediction interval.</p></div></div>`;
  const areaSelect = $('#forecast-area'); areaSelect.value = `${state.region}::${state.area}`;
  $('#scenario-adjustment').addEventListener('input', (e) => $('#scenario-label').textContent = `${Number(e.target.value) > 0 ? '+' : ''}${e.target.value}%`);
  $('#run-forecast').addEventListener('click', runForecast);
  $('#forecast-data-end').textContent = $('#dataset-last-date').textContent;
  // Run a model-status summary in the background; avoid expensive training until requested.
  $('#run-forecast').focus({ preventScroll: true });
}

function areaOptions() { return state.areas.map(a => `<option value="${escapeHtml(a.key)}">${escapeHtml(a.area)} · ${escapeHtml(a.state)}</option>`).join(''); }

async function runForecast() {
  const button = $('#run-forecast'); if (!button) return;
  const selected = ($('#forecast-area').value || `${state.region}::${state.area}`).split('::');
  const stateName = selected[0] || state.region, area = selected[1] || state.area;
  const horizon = Number($('#forecast-horizon').value || 7), scenario = Number($('#scenario-adjustment').value || 0);
  button.disabled = true; button.innerHTML = '<span class="loader-inline"></span> Training and evaluating…';
  $('#forecast-list').innerHTML = '<div class="loading-screen" style="min-height:240px"><div class="loader-ring"></div><p>Evaluating time-aware model candidates…</p></div>';
  try {
    const [model, forecast, hist] = await Promise.all([
      api(`/api/models?area=${encodeURIComponent(area)}&state=${encodeURIComponent(stateName)}`),
      api(`/api/forecast?area=${encodeURIComponent(area)}&state=${encodeURIComponent(stateName)}&horizon=${horizon}&scenario_pct=${scenario}`),
      api(`/api/history?area=${encodeURIComponent(area)}&state=${encodeURIComponent(stateName)}&days=90`)
    ]);
    state.lastModel = model; state.lastForecast = forecast;
    const metrics = model.test_metrics;
    $('#forecast-summary').innerHTML = `<div class="forecast-stat"><span>SELECTED MODEL</span><b>${escapeHtml(model.model_name)}</b><small>Chosen by validation MAE</small></div><div class="forecast-stat"><span>TEST MAE</span><b>${fmtNum(metrics.selected_model.mae,2)}</b><small>Persistence baseline: ${fmtNum(metrics.persistence_baseline.mae,2)}</small></div><div class="forecast-stat"><span>HISTORY ENDS</span><b>${fmtDate(forecast.source_last_observation)}</b><small>Forecast begins ${fmtDate(forecast.forecast_start)}</small></div>`;
    $('#forecast-chart-subtitle').textContent = `${forecast.area}, ${forecast.state} · ${forecast.horizon}-day horizon · source cutoff ${fmtDate(forecast.source_last_observation)}`;
    drawForecastChart($('#forecast-chart'), hist.records, forecast.forecast);
    $('#forecast-list').innerHTML = `<div class="muted" style="font-size:9px;line-height:1.7;margin-bottom:8px">${escapeHtml(forecast.note)}</div>${forecast.forecast.map(r => `<div class="forecast-row"><div class="forecast-day"><b>${fmtDate(r.date,{weekday:'short',day:'2-digit',month:'short',year:'numeric'})}</b><small>${badge(r.category,aqiTone(r.predicted_aqi))} ${r.scenario_pct ? `· ${r.scenario_pct>0?'+':''}${r.scenario_pct}% scenario` : ''}</small></div><div class="forecast-number" style="color:${toneColor(r.predicted_aqi)}">${fmtNum(r.predicted_aqi,1)}</div><div class="forecast-band">${fmtNum(r.lower_estimate,0)}–${fmtNum(r.upper_estimate,0)}<small style="display:block;color:#657b95;margin-top:3px">indicative</small></div></div>`).join('')}<div class="note-box" style="margin-top:14px"><b>Historical forecast notice:</b> These dates follow the last data point in the supplied dataset, not today's date. The scenario slider applies a user-defined percentage to the model estimate.</div>`;
    toast('Forecast experiment completed.', 'success');
  } catch (error) {
    $('#forecast-list').innerHTML = `<div class="error-state"><b>Experiment could not complete</b><p>${escapeHtml(error.message)}</p><p>Check package installation and the backend terminal for details.</p></div>`;
    toast(error.message, 'error');
  } finally { button.disabled = false; button.innerHTML = '<span class="button-icon">✳</span> Run experiment'; }
}

async function renderRegionsPage() {
  const app = $('#app-view');
  app.innerHTML = pageHeader('SPATIAL COMPARISON / 03', 'Regional explorer', 'Compare the latest available AQI observations across cities and states. Coverage dates differ by region, so review the date column when interpreting rankings.', `${downloadButton()}`)
  + `<div class="region-layout"><section class="panel"><div class="panel-header"><div><div class="panel-title">Regional ranking</div><div class="panel-subtitle" id="region-subtitle">Loading latest available records…</div></div><span class="badge muted">AREA LEVEL</span></div><div class="table-toolbar"><div class="left"><div class="search-field"><input class="input" id="region-search" placeholder="Search city or state…"/></div></div><div class="right"><select class="select-control" style="width:160px" id="region-sort"><option value="highest">Highest AQI first</option><option value="lowest">Lowest AQI first</option><option value="name">Area name</option></select></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Area / State</th><th>AQI</th><th>Band</th><th>Latest observation</th><th>Stations</th></tr></thead><tbody id="region-table"><tr><td colspan="5">Loading…</td></tr></tbody></table></div><div class="table-footer"><span id="region-count">—</span><span>Use search to narrow the view</span></div></section><aside class="panel"><div class="panel-header"><div><div class="panel-title">Regional risk distribution</div><div class="panel-subtitle">Share of latest rows by category, across all areas</div></div></div><div class="panel-body"><div id="region-distribution" class="category-stack"><div class="skeleton" style="height:10px"></div></div><hr class="section-divider"><div class="note-box"><b>Comparability note</b><br>The dataset contains different coverage histories per area. This explorer uses each area's latest row; rankings are not a synchronized live snapshot.</div><div style="margin-top:14px"><button class="button" id="export-selected">Export selected area CSV <span>↓</span></button></div></div></aside></div>`;
  $('#region-search').addEventListener('input', debounce(loadRegions, 220));
  $('#region-sort').addEventListener('change', loadRegions);
  $('#export-selected').addEventListener('click', () => { window.location.href = `/api/export?${areaArgs()}`; });
  await loadRegions();
}

function debounce(fn, wait) { let timer; return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); }; }
async function loadRegions() {
  const search = $('#region-search')?.value || '', sort = $('#region-sort')?.value || 'highest';
  const data = await api(`/api/regions?sort=${sort}&limit=100&search=${encodeURIComponent(search)}`);
  $('#region-subtitle').textContent = `${data.count} areas in the current view · latest available row through ${fmtDate(data.as_of)}`;
  $('#region-count').textContent = `Showing ${data.regions.length} area records`;
  $('#region-table').innerHTML = data.regions.map(r => `<tr><td><span class="table-area">${escapeHtml(r.area)}</span><br><span class="muted">${escapeHtml(r.state)}</span></td><td class="mono">${fmtNum(r.aqi)}</td><td>${badge(r.category,aqiTone(r.aqi))}</td><td>${fmtDate(r.date)}</td><td>${r.stations ?? '—'}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">No areas match that search.</td></tr>';
  const counts = data.regions.reduce((acc, r) => { acc[r.category] = (acc[r.category] || 0) + 1; return acc; }, {});
  renderCategoryStackInto($('#region-distribution'), counts);
}
function renderCategoryStackInto(container, distribution) {
  const order = ['Good','Satisfactory','Moderate','Poor','Very Poor','Severe']; const total = Object.values(distribution).reduce((a,b)=>a+b,0) || 1;
  container.innerHTML = order.map(name=>{const count=distribution[name]||0;return `<div class="category-row"><span class="category-name">${name}</span><div class="category-bar"><div class="category-fill" style="width:${count/total*100}%;background:${toneColor(({Good:25,Satisfactory:75,Moderate:150,Poor:250,'Very Poor':350,Severe:450})[name])}"></div></div><span class="category-count">${fmtNum(count)}</span></div>`}).join('');
}

async function renderModelsPage() {
  const app = $('#app-view');
  app.innerHTML = pageHeader('MODEL GOVERNANCE / 04', 'Model bench', 'Compare candidate regressors with a chronological validation split, inspect the held-out test result, and see how much the selected model improves on a persistence baseline.', `<button class="button" id="retrain-model"><span class="button-icon">⟳</span> Retrain evaluation</button><span class="badge muted">SCIKIT-LEARN</span>`)
  + `<div class="metric-grid" id="model-metrics"><div class="metric-card"><span>SELECTED MODEL</span><b>—</b><small>Loading metrics</small></div><div class="metric-card"><span>TEST MAE</span><b>—</b><small>Lower is better</small></div><div class="metric-card"><span>BASELINE MAE</span><b>—</b><small>Persistence: prior day's AQI</small></div></div><div class="content-grid"><section class="panel"><div class="panel-header"><div><div class="panel-title">Validation comparison</div><div class="panel-subtitle">Model selection uses validation mean absolute error (MAE)</div></div><span class="badge muted">UNSEEN VALIDATION WINDOW</span></div><div class="table-wrap"><table class="data-table model-table"><thead><tr><th>Model</th><th>Validation MAE</th><th>RMSE</th><th>R²</th><th>Selection</th></tr></thead><tbody id="model-table"><tr><td colspan="5">Evaluating models…</td></tr></tbody></table></div><div class="panel-body"><div class="bar-chart-wrap"><canvas class="chart-canvas" id="model-chart"></canvas></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Held-out test result</div><div class="panel-subtitle" id="test-period">Later chronological holdout</div></div></div><div class="panel-body" id="test-result"><div class="loading-screen" style="min-height:170px"><div class="loader-ring"></div><p>Training/evaluating candidate models…</p></div></div><hr class="section-divider"/><div class="panel-body"><div class="panel-title">Evaluation design</div><div class="check-list" style="margin-top:11px"><div class="check-item"><span class="check-icon">✓</span><div class="check-copy"><b>Chronological split</b><span>Earlier rows train the model; later rows validate/test.</span></div>${badge('PASS','green')}</div><div class="check-item"><span class="check-icon">✓</span><div class="check-copy"><b>Persistence baseline</b><span>Compare against using the prior day's AQI.</span></div>${badge('PASS','green')}</div><div class="check-item"><span class="check-icon review">!</span><div class="check-copy"><b>Limited predictors</b><span>Historical AQI lags only; no weather or emissions data.</span></div>${badge('LIMIT','amber')}</div></div></div></section></div><div class="split-heading"><h2>Feature influence</h2><span>Relative importance / normalized absolute coefficient</span></div><section class="panel"><div class="panel-header"><div><div class="panel-title">Signals used by the selected production model</div><div class="panel-subtitle">Lagged AQI and calendar seasonality features</div></div></div><div class="panel-body"><div id="feature-importance" class="category-stack"><div class="skeleton" style="height:10px"></div></div></div></section>`;
  $('#retrain-model').addEventListener('click', async () => { try { await loadModelBench(true); toast('Model evaluation refreshed.'); } catch(e) { toast(e.message, 'error'); } });
  await loadModelBench(false);
}

async function loadModelBench(force) {
  const model = await api(`/api/models?${areaArgs()}${force ? '&retrain=true' : ''}`);
  state.lastModel = model;
  const test = model.test_metrics;
  $('#model-metrics').innerHTML = `<div class="metric-card"><span>SELECTED MODEL</span><b style="font-size:18px">${escapeHtml(model.model_name)}</b><small>Selected by validation MAE</small></div><div class="metric-card"><span>TEST MAE</span><b>${fmtNum(test.selected_model.mae,2)}</b><small>RMSE ${fmtNum(test.selected_model.rmse,2)} · R² ${fmtNum(test.selected_model.r2,3)}</small></div><div class="metric-card"><span>BASELINE MAE</span><b>${fmtNum(test.persistence_baseline.mae,2)}</b><small>${test.mae_improvement_percent >= 0 ? `${fmtNum(test.mae_improvement_percent,1)}% lower error` : `${fmtNum(Math.abs(test.mae_improvement_percent),1)}% higher error`} than persistence</small></div>`;
  $('#test-period').textContent = `${fmtDate(model.split.test_start)} – ${fmtDate(model.split.test_end)} · ${model.split.test_rows} observations`;
  $('#model-table').innerHTML = model.validation_models.map(m => `<tr class="${m.name===model.model_name?'selected-model':''}"><td class="table-area">${escapeHtml(m.name)}</td><td class="mono">${fmtNum(m.validation.mae,3)}</td><td class="mono">${fmtNum(m.validation.rmse,3)}</td><td class="mono">${fmtNum(m.validation.r2,3)}</td><td>${m.name===model.model_name?badge('SELECTED','green'):badge('CANDIDATE','muted')}</td></tr>`).join('');
  $('#test-result').innerHTML = `<div class="category-row" style="grid-template-columns:1fr 85px;margin-bottom:10px"><span class="category-name">Selected model MAE</span><b class="mono" style="text-align:right">${fmtNum(test.selected_model.mae,2)}</b></div><div class="category-bar"><div class="category-fill" style="width:${Math.min(100,test.selected_model.mae/Math.max(test.selected_model.mae,test.persistence_baseline.mae)*100)}%;background:var(--teal)"></div></div><div class="category-row" style="grid-template-columns:1fr 85px;margin:14px 0 10px"><span class="category-name">Persistence baseline MAE</span><b class="mono" style="text-align:right">${fmtNum(test.persistence_baseline.mae,2)}</b></div><div class="category-bar"><div class="category-fill" style="width:${Math.min(100,test.persistence_baseline.mae/Math.max(test.selected_model.mae,test.persistence_baseline.mae)*100)}%;background:var(--amber)"></div></div><hr class="section-divider"><div class="muted" style="font-size:10px;line-height:1.8">${test.mae_improvement_percent >= 0 ? 'The selected model improved on the baseline in this test window.' : 'The selected model did not outperform the persistence baseline in this test window.'} This result is specific to the supplied historical period, not a guarantee for future data.</div>`;
  $('#feature-importance').innerHTML = (model.feature_importance || []).slice(0,10).map(x=>`<div class="category-row" style="grid-template-columns:105px 1fr 50px"><span class="category-name">${escapeHtml(x.feature)}</span><div class="category-bar"><div class="category-fill" style="width:${Math.max(0,Math.min(100,x.importance*100))}%;background:linear-gradient(90deg,#62e3cb,#417ee8)"></div></div><span class="category-count">${fmtNum(x.importance*100,1)}%</span></div>`).join('') || '<p class="muted">Importance not available for this model.</p>';
  drawModelChart($('#model-chart'), model.validation_models, model.model_name);
}
function drawModelChart(canvas, candidates, selectedName) {
  if (!canvas) return; const ctx=setupCanvas(canvas); if(!ctx)return; const w=canvas.width,h=canvas.height,dpr=window.devicePixelRatio||1;ctx.clearRect(0,0,w,h);const pad={left:110*dpr,right:35*dpr,top:13*dpr,bottom:10*dpr};const plotW=w-pad.left-pad.right;const data=candidates||[];const max=Math.max(1,...data.map(d=>Number(d.validation.mae)));ctx.font=`${10*dpr}px system-ui`;data.forEach((d,i)=>{const y=pad.top+i*42*dpr;ctx.fillStyle='#8095ae';ctx.textAlign='right';ctx.textBaseline='middle';ctx.fillText(d.name,pad.left-10*dpr,y+8*dpr);const barW=Number(d.validation.mae)/max*plotW;ctx.fillStyle=d.name===selectedName?'#62e3cb':'#35516e';roundRect(ctx,pad.left,y,barW,17*dpr,4*dpr);ctx.fill();ctx.fillStyle='#dbe8f7';ctx.textAlign='left';ctx.fillText(Number(d.validation.mae).toFixed(2),Math.min(w-30*dpr,pad.left+barW+6*dpr),y+8*dpr)});
}

async function renderQualityPage() {
  const app = $('#app-view');
  app.innerHTML = pageHeader('DATA TRUST / 05', 'Data quality & provenance', 'A model is only as trustworthy as its data. Review completeness, duplicate keys, category-label consistency, and missing calendar days before interpreting predictions.', `${downloadButton()}<a class="button" href="/api/docs" target="_blank" rel="noreferrer">API documentation ↗</a>`)
  + `<div class="quality-grid" id="quality-grid"><div class="quality-stat"><span>Source rows</span><b>—</b></div><div class="quality-stat"><span>Source areas</span><b>—</b></div><div class="quality-stat"><span>Date span</span><b>—</b></div><div class="quality-stat"><span>Label mismatches</span><b>—</b></div></div><div class="content-grid"><section class="panel"><div class="panel-header"><div><div class="panel-title">Automated validation checks</div><div class="panel-subtitle">Pass, review, or informational items from data ingestion</div></div><span class="badge muted">DATA CONTRACT</span></div><div class="panel-body"><div class="check-list" id="quality-checks"><div class="skeleton" style="height:48px"></div><div class="skeleton" style="height:48px"></div><div class="skeleton" style="height:48px"></div></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Selected area gaps</div><div class="panel-subtitle">Calendar dates without an observation</div></div></div><div class="panel-body"><div id="missing-dates-list" class="check-list"><div class="skeleton" style="height:48px"></div></div><hr class="section-divider"><div class="panel-title">Missing values by field</div><div id="missing-fields" class="category-stack" style="margin-top:12px"></div></div></section></div><div class="split-heading"><h2>Category-label review</h2><span>Source label vs. numeric AQI band</span></div><section class="panel"><div class="panel-header"><div><div class="panel-title">Potential AQI status mismatches</div><div class="panel-subtitle">The application does not silently rewrite original source labels</div></div><span class="badge amber">REVIEW REQUIRED IF PRESENT</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Area</th><th>Source AQI</th><th>Source label</th><th>Expected band</th></tr></thead><tbody id="mismatch-table"><tr><td colspan="5">Loading…</td></tr></tbody></table></div></section><div class="note-box" style="margin-top:15px"><b>Methodology note:</b> blank note fields are informational if the column is optional. Missing calendar dates are not automatically filled with invented AQI observations. The time-series model uses lag features and excludes rows whose required historic values are unavailable.</div>`;
  const data = await api(`/api/data-quality?${areaArgs()}`);
  $('#quality-grid').innerHTML = `<div class="quality-stat"><span>Normalized source rows</span><b>${fmtNum(data.rows)}</b><small>After parse/range checks</small></div><div class="quality-stat"><span>States / areas</span><b>${fmtNum(data.states)} / ${fmtNum(data.areas)}</b><small>Distinct geographic labels</small></div><div class="quality-stat"><span>Dataset date span</span><b style="font-size:14px">${fmtDate(data.date_min,{day:'2-digit',month:'short',year:'numeric'})}<br>to ${fmtDate(data.date_max,{day:'2-digit',month:'short',year:'numeric'})}</b><small>${fmtNum(data.unique_dates)} observed dates</small></div><div class="quality-stat"><span>Label mismatches</span><b>${fmtNum(data.category_mismatches)}</b><small>Source vs. standard band</small></div>`;
  $('#quality-checks').innerHTML = (data.checks||[]).map(c=>`<div class="check-item"><span class="check-icon ${c.status==='review'?'review':c.status==='info'?'info':''}">${c.status==='pass'?'✓':c.status==='review'?'!':'i'}</span><div class="check-copy"><b>${escapeHtml(c.name)}</b><span>${escapeHtml(c.detail)}</span></div>${badge(c.status.toUpperCase(),c.status==='pass'?'green':c.status==='review'?'amber':'muted')}</div>`).join('');
  const missing = data.selected_area?.missing_calendar_dates || [];
  $('#missing-dates-list').innerHTML = missing.length ? missing.map(d=>`<div class="check-item"><span class="check-icon review">!</span><div class="check-copy"><b>${fmtDate(d)}</b><span>No record for this calendar date</span></div>${badge('GAP','amber')}</div>`).join('') : `<div class="check-item"><span class="check-icon">✓</span><div class="check-copy"><b>No calendar gaps found</b><span>Within selected area's observation window.</span></div>${badge('PASS','green')}</div>`;
  $('#missing-fields').innerHTML = Object.entries(data.missing_values||{}).map(([name,count])=>`<div class="category-row"><span class="category-name">${escapeHtml(name)}</span><div class="category-bar"><div class="category-fill" style="width:${Number(count)/Math.max(1,data.rows)*100}%;background:${count?'var(--amber)':'var(--teal)'}"></div></div><span class="category-count">${fmtNum(count)}</span></div>`).join('');
  const samples = data.selected_area?.mismatch_samples || [];
  $('#mismatch-table').innerHTML = samples.length ? samples.map(r=>`<tr><td>${fmtDate(r.date)}</td><td class="table-area">${escapeHtml(state.area)}</td><td class="mono">${fmtNum(r.aqi)}</td><td>${badge(r.source_label,'muted')}</td><td>${badge(r.expected_label,aqiTone(r.aqi))}</td></tr>`).join('') : '<tr><td colspan="5" class="muted">No selected-area status mismatches found in this dataset.</td></tr>';
}

function renderProjectPage() {
  const app=$('#app-view');
  app.innerHTML=pageHeader('DOCUMENTATION / 06','Project brief','A technically grounded final-year project with data provenance, time-aware evaluation, an API backend, and an interactive frontend.',`${downloadButton()}<a class="button" href="/api/docs" target="_blank" rel="noreferrer">Explore API ↗</a>`)
  +`<div class="project-layout"><div><section class="project-hero"><div class="section-kicker">B.TECH PROJECT · ML + FULL-STACK ANALYTICS</div><h2>Smart Environmental Risk Prediction & Analytics</h2><p>A research-oriented web application for understanding historical air-quality patterns, comparing regional observations, and experimenting with next-day AQI forecasting using lagged historical signals.</p><div class="badge-row">${badge('Python + FastAPI','green')}${badge('Pandas / Scikit-learn','muted')}${badge('Responsive frontend','muted')}${badge('Time-aware evaluation','amber')}</div></section><div class="split-heading"><h2>Core capabilities</h2><span>What the demo shows</span></div><div class="insight-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="insight-card"><div class="insight-icon">▥</div><b>Historical analytics</b><p>Interactive AQI trends, monthly aggregates, category distributions, and CSV export.</p></div><div class="insight-card"><div class="insight-icon">⌁</div><b>Experimental forecast</b><p>Chronological model selection, an explainable persistence baseline, and short-range recursive forecasts.</p></div><div class="insight-card"><div class="insight-icon">◎</div><b>Regional exploration</b><p>Searchable area rankings using each area's latest available record.</p></div><div class="insight-card"><div class="insight-icon">✓</div><b>Data quality</b><p>Coverage gaps, missing fields, source-label differences, and model limitations.</p></div></div><div class="split-heading"><h2>Known limitations</h2><span>Discuss in viva</span></div><div class="check-list"><div class="check-item"><span class="check-icon review">!</span><div class="check-copy"><b>Historical cutoff</b><span>The supplied file ends on 30 April 2025; the app does not claim to provide today's AQI.</span></div>${badge('IMPORTANT','amber')}</div><div class="check-item"><span class="check-icon review">!</span><div class="check-copy"><b>No meteorology features</b><span>Weather, wind, temperature, rainfall, industrial emissions and traffic are not included in the forecasting model.</span></div>${badge('LIMITATION','amber')}</div><div class="check-item"><span class="check-icon review">!</span><div class="check-copy"><b>Area labels aren't sensor-level trajectories</b><span>The source is aggregated by area and date; station-level variation may be hidden.</span></div>${badge('LIMITATION','amber')}</div></div></div><aside><section class="panel"><div class="panel-header"><div><div class="panel-title">System architecture</div><div class="panel-subtitle">Local full-stack setup</div></div></div><div class="architecture-flow"><div class="architecture-step"><span class="step-num">01</span><div><b>Historical CSV in ZIP</b><small>235K+ daily area rows</small></div></div><div class="architecture-arrow">↓</div><div class="architecture-step"><span class="step-num">02</span><div><b>Data service</b><small>Parse, validate, aggregate</small></div></div><div class="architecture-arrow">↓</div><div class="architecture-step"><span class="step-num">03</span><div><b>ML model service</b><small>Lag features · chronological split</small></div></div><div class="architecture-arrow">↓</div><div class="architecture-step"><span class="step-num">04</span><div><b>FastAPI REST endpoints</b><small>Summary · forecast · export</small></div></div><div class="architecture-arrow">↓</div><div class="architecture-step"><span class="step-num">05</span><div><b>Interactive dashboard</b><small>HTML · CSS · JavaScript · Canvas</small></div></div></div></section><section class="panel" style="margin-top:15px"><div class="panel-header"><div><div class="panel-title">API quick links</div><div class="panel-subtitle">Backend endpoints for review</div></div></div><div class="panel-body" style="display:flex;flex-direction:column;gap:8px"><a class="button" href="/api/health" target="_blank">GET /api/health ↗</a><a class="button" href="/api/summary" target="_blank">GET /api/summary ↗</a><a class="button" href="/api/data-quality" target="_blank">GET /api/data-quality ↗</a><a class="button" href="/api/docs" target="_blank">Interactive Swagger docs ↗</a></div></section><section class="panel" style="margin-top:15px"><div class="panel-header"><div><div class="panel-title">Dataset provenance</div><div class="panel-subtitle">Source provided for this project</div></div></div><div class="panel-body"><p class="muted" style="font-size:10px;line-height:1.8">The included ZIP contains <code>aqi.csv</code>, with observations from 1 April 2022 to 30 April 2025. Preserve the source URL, license and attribution details in your seminar report according to the original download terms.</p><a class="button small-button" href="/api/export?${areaArgs()}">Export current area data ↓</a></div></section></aside></div>`;
}

async function showAlertsModal() {
  $('#modal-backdrop').classList.remove('hidden');
  $('#modal-content').innerHTML='<div class="loading-screen" style="min-height:150px"><div class="loader-ring"></div><p>Loading latest historical alert rows…</p></div>';
  try {
    const data=await api('/api/alerts?limit=18');
    $('#modal-content').innerHTML=data.alerts.length?data.alerts.map(a=>`<div class="alert-item"><div><b>${escapeHtml(a.area)} <span class="muted">· ${escapeHtml(a.state)}</span></b><small>${escapeHtml(a.message)} · ${fmtDate(a.date)} · ${a.category}</small></div><div class="alert-num" style="color:${toneColor(a.aqi)}">${fmtNum(a.aqi)}</div></div>`).join(''):'<div class="empty-state">No observations above the alert threshold in this dataset.</div>';
  } catch(e) { $('#modal-content').innerHTML=`<div class="error-state">${escapeHtml(e.message)}</div>`; }
}

// Main navigation and global controls.
$$('.nav-item').forEach(button => button.addEventListener('click', () => navigate(button.dataset.view)));
$$('[data-view-link]').forEach(link => link.addEventListener('click', (e) => { e.preventDefault(); navigate(link.dataset.viewLink); }));
$('#global-area').addEventListener('change', (event) => {
  const [region, area] = event.target.value.split('::');
  if (!region || !area) return;
  state.region = region; state.area = area;
  toast(`Workspace switched to ${area}, ${region}.`, 'success');
  navigate(state.view);
});
$('#alerts-button').addEventListener('click', showAlertsModal);
$('#modal-close').addEventListener('click', () => $('#modal-backdrop').classList.add('hidden'));
$('#modal-backdrop').addEventListener('click', (e) => { if (e.target === $('#modal-backdrop')) $('#modal-backdrop').classList.add('hidden'); });
$('#theme-toggle').addEventListener('click', () => {
  document.body.classList.toggle('light-theme');
  state.theme = document.body.classList.contains('light-theme') ? 'light' : 'dark';
  localStorage.setItem('aero-theme', state.theme);
  toast(`${state.theme === 'light' ? 'Light' : 'Dark'} contrast enabled.`);
  // Repaint canvases using their current data if the view contains any.
  if (state.view === 'overview') navigate('overview');
  else if (state.view === 'forecast' && state.lastForecast) runForecast();
});
window.addEventListener('resize', debounce(() => {
  if (state.view === 'overview' && state.summary) navigate('overview');
  else if (state.view === 'forecast' && state.lastForecast) runForecast();
  else if (state.view === 'models' && state.lastModel) drawModelChart($('#model-chart'), state.lastModel.validation_models, state.lastModel.model_name);
}, 180));

initialize();
