# Seminar demonstration guide (5–7 minutes)

## Before class

1. Extract this project and run `run_windows.bat`.
2. Open `http://127.0.0.1:8000` in your browser.
3. Keep the terminal open throughout the demo.
4. Open **Model bench** before presenting the forecast lab. The first ML evaluation may take several seconds; later requests are cached for the current server session.
5. Have the terminal and API docs (`/api/docs`) ready as a fallback.

## Suggested demo flow

### 1. Overview (45 seconds)

Explain that the app uses a supplied daily AQI dataset from 1 April 2022 to 30 April 2025. Point out the latest observation, historical mean, peak, AQI timeline and monthly signal. Emphasize the historical cutoff.

### 2. Regional explorer (45 seconds)

Search a city or state and sort by highest or lowest AQI. Point to the observation date; each area's latest record may be from a different date, so do not describe this as a synchronized live ranking.

### 3. Data quality (45 seconds)

Show the dataset coverage, blank `note` column, category checks, and missing calendar dates for Ahmedabad. Explain that missing dates are not filled with fabricated AQI values.

### 4. Model bench (60–90 seconds)

Run the model evaluation. Explain:
- Lag features use AQI values from prior days.
- A chronological validation split is used to select among Ridge Regression, Random Forest, and Gradient Boosting.
- A later holdout test is compared to a persistence baseline (using the prior day's AQI).
- The test metric is a rolling one-step-ahead evaluation; longer recursive forecasts can be less reliable.

A checked local run on the included data selected **Ridge Regression** with validation MAE **14.261**. On the later holdout, its MAE was **21.480**, compared with **22.456** for the persistence baseline; RMSE was **27.388** versus **29.726**. These values are specific to this dataset and the installed package versions; quote the values displayed by your own run if they differ.

### 5. Forecast lab (60–90 seconds)

Choose a 1-, 3-, 7- or 14-day horizon and run the experiment. The included data ends on 30 April 2025, so the dates forecast by the current archive are from 1 May 2025 onward. The scenario slider is a transparent percentage what-if overlay, not a physics-based weather scenario.

### 6. Backend (30 seconds)

Open **API documentation** and show endpoints such as `/api/health`, `/api/summary`, `/api/models`, and `/api/forecast`.

## Answers to expected viva questions

**Why did you choose Ridge Regression?** The application compares candidate regressors and selects the one with the lowest validation MAE. In the checked run, Ridge was marginally better on validation. The selected model is then assessed on a later holdout.

**Why not report only R²?** MAE tells us the average absolute AQI error in index points and is easier to explain operationally. RMSE penalizes larger errors more heavily. R² indicates variance explained relative to a constant-mean baseline. No metric proves the model is always reliable.

**How do you avoid leakage?** Features are created from lagged values only. Rows are split in chronological order; validation is used for model selection and the test set is held out until final evaluation.

**Does it show real-time AQI?** No. The included source dataset ends on 30 April 2025. Real-time use would require a permitted, reliable updated data source and ongoing monitoring.

**What are the limitations?** No weather, wind, rainfall, traffic, emissions, or station-level sensor features are included. The source is aggregated by area/day, and data-label inconsistencies are flagged for review.

**What would you improve next?** Add verified updated observations; compare against a seasonal-naive baseline; use rolling-origin backtesting; add weather covariates with matching timestamps; calibrate forecast intervals; add automated tests and deployment monitoring.

## GitHub publishing reminder

Before publishing the repository, add the exact source dataset URL and license/attribution terms to `data/SOURCE.md`. If redistribution is not allowed, remove the raw ZIP from the public repository and document how users can obtain the dataset independently. Never publish secrets or personal data.
