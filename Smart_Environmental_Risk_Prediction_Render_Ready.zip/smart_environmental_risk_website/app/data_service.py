"""Data access, data-quality checks, and aggregation for the AQI application."""
from __future__ import annotations

from functools import lru_cache
from io import BytesIO, StringIO
from pathlib import Path
from zipfile import ZipFile
import json

import numpy as np
import pandas as pd

from .config import DATA_ZIP, RAW_DIR, PROCESSED_DIR, REPORTS_DIR

REQUIRED_COLUMNS = [
    "date", "state", "area", "number_of_monitoring_stations",
    "prominent_pollutants", "aqi_value", "air_quality_status", "unit", "note"
]


def aqi_category(value: float | int | None) -> str:
    if value is None or pd.isna(value):
        return "Unknown"
    v = float(value)
    if v <= 50:
        return "Good"
    if v <= 100:
        return "Satisfactory"
    if v <= 200:
        return "Moderate"
    if v <= 300:
        return "Poor"
    if v <= 400:
        return "Very Poor"
    return "Severe"


def category_color(category: str) -> str:
    return {
        "Good": "green", "Satisfactory": "lime", "Moderate": "amber",
        "Poor": "orange", "Very Poor": "red", "Severe": "violet", "Unknown": "muted"
    }.get(category, "muted")


@lru_cache(maxsize=1)
def load_data() -> pd.DataFrame:
    """Load the original CSV from the supplied ZIP and normalize core fields."""
    csv_path = RAW_DIR / "aqi.csv"
    if csv_path.exists():
        df = pd.read_csv(csv_path)
        source_label = csv_path.name
    elif DATA_ZIP.exists():
        with ZipFile(DATA_ZIP) as zf:
            csv_members = [n for n in zf.namelist() if n.lower().endswith(".csv")]
            if not csv_members:
                raise FileNotFoundError("The dataset ZIP does not contain a CSV file.")
            preferred = next((n for n in csv_members if Path(n).name.lower() == "aqi.csv"), csv_members[0])
            with zf.open(preferred) as handle:
                df = pd.read_csv(handle)
        source_label = f"{DATA_ZIP.name} → {Path(preferred).name}"
    else:
        raise FileNotFoundError(
            f"AQI dataset not found. Expected {DATA_ZIP} or {csv_path}. "
            "Keep the included data/raw/archive (1).zip file in place."
        )

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")

    # Dataset dates are formatted as day-month-year (e.g. 30-04-2025).
    df["date"] = pd.to_datetime(df["date"], format="%d-%m-%Y", errors="coerce")
    df["aqi_value"] = pd.to_numeric(df["aqi_value"], errors="coerce")
    df["number_of_monitoring_stations"] = pd.to_numeric(
        df["number_of_monitoring_stations"], errors="coerce"
    )
    for col in ["state", "area", "prominent_pollutants", "air_quality_status", "unit"]:
        df[col] = df[col].astype("string").str.strip()
    df["source_status"] = df["air_quality_status"].fillna("Unknown").astype(str)
    df["expected_status"] = df["aqi_value"].map(aqi_category)
    df["status_mismatch"] = (
        df["aqi_value"].notna()
        & df["air_quality_status"].notna()
        & df["expected_status"].ne(df["air_quality_status"].astype(str))
    )
    df = df.dropna(subset=["date", "state", "area", "aqi_value"]).copy()
    df = df[df["aqi_value"].between(0, 500)].copy()
    df = df.drop_duplicates(subset=["date", "state", "area"], keep="last")
    df = df.sort_values(["state", "area", "date"]).reset_index(drop=True)
    df["category"] = df["aqi_value"].map(aqi_category)
    df["source_label"] = source_label

    # Store a normalized full dataset and a compact Gujarat/Ahmedabad subset for transparency.
    cols = ["date", "state", "area", "number_of_monitoring_stations", "prominent_pollutants",
            "aqi_value", "air_quality_status", "expected_status", "status_mismatch", "unit"]
    df[cols].to_csv(PROCESSED_DIR / "aqi_normalized.csv", index=False, date_format="%Y-%m-%d")
    return df


def select_area(df: pd.DataFrame, area: str = "Ahmedabad", state: str | None = "Gujarat") -> pd.DataFrame:
    area_norm = str(area or "Ahmedabad").strip().casefold()
    selected = df[df["area"].str.casefold() == area_norm]
    if state:
        state_norm = str(state).strip().casefold()
        selected = selected[selected["state"].str.casefold() == state_norm]
    if selected.empty:
        raise ValueError(f"No records found for area '{area}'" + (f" in '{state}'" if state else "") + ".")
    return selected.sort_values("date").copy()


def latest_record(group: pd.DataFrame) -> pd.Series:
    return group.sort_values("date").iloc[-1]


def data_quality_summary(df: pd.DataFrame) -> dict:
    missing = {str(k): int(v) for k, v in df[REQUIRED_COLUMNS].isna().sum().items()}
    # Raw note was entirely empty in the supplied data; this is informational, not a quality failure.
    raw_note_empty = bool(df["note"].isna().all())
    group_sizes = df.groupby(["date", "state", "area"], dropna=False).size()
    duplicates = int((group_sizes - 1).clip(lower=0).sum())
    key_pairs = df[["state", "area"]].drop_duplicates().shape[0]
    dates = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
    return {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "date_min": df["date"].min().strftime("%Y-%m-%d"),
        "date_max": df["date"].max().strftime("%Y-%m-%d"),
        "unique_dates": int(df["date"].nunique()),
        "states": int(df["state"].nunique()),
        "areas": int(key_pairs),
        "missing_values": missing,
        "duplicate_date_state_area_rows": duplicates,
        "invalid_aqi_rows_after_cleaning": int((~df["aqi_value"].between(0, 500)).sum()),
        "category_mismatches": int(df["status_mismatch"].sum()),
        "note_column_empty": raw_note_empty,
        "missing_note_rows": int(df["note"].isna().sum()),
        "expected_calendar_days_in_global_period": int(len(dates)),
        "source": str(df["source_label"].iloc[0]) if len(df) else "unknown",
        "checks": [
            {"name": "AQI values within 0–500", "status": "pass", "detail": "Out-of-range values are excluded during load."},
            {"name": "Date parsing", "status": "pass", "detail": "Unparseable dates are excluded during load."},
            {"name": "Date/state/area duplicate keys", "status": "pass" if duplicates == 0 else "review", "detail": f"{duplicates:,} duplicate keys after normalization."},
            {"name": "Blank notes column", "status": "info" if raw_note_empty else "pass", "detail": "All note entries are blank; column is retained in source but not used by the model."},
            {"name": "AQI status consistency", "status": "review" if int(df["status_mismatch"].sum()) else "pass", "detail": f"{int(df['status_mismatch'].sum()):,} rows have a source label that differs from the standard numeric AQI band."},
        ],
    }


def get_area_records(df: pd.DataFrame) -> list[dict]:
    records = df[["state", "area"]].drop_duplicates().sort_values(["state", "area"])
    return [{"state": str(r.state), "area": str(r.area), "key": f"{r.state}::{r.area}"} for r in records.itertuples(index=False)]
