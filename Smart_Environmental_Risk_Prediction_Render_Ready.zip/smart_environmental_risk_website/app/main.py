"""FastAPI application for Smart Environmental Risk Prediction and Analytics."""
from __future__ import annotations

from io import StringIO
from pathlib import Path
from typing import Optional

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .config import FRONTEND_DIR, ASSETS_DIR, REPORTS_DIR
from .data_service import load_data, select_area, aqi_category, category_color, data_quality_summary, get_area_records
from .ml_service import registry

app = FastAPI(
    title="Smart Environmental Risk Prediction & Analytics API",
    description="Historical air-quality analytics, time-aware machine learning evaluation, and retrospective AQI forecasting.",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)
app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")


def _records(df: pd.DataFrame) -> list[dict]:
    if df.empty:
        return []
    view = df.sort_values("date")
    out = []
    for r in view.itertuples(index=False):
        out.append({
            "date": pd.Timestamp(getattr(r, "date")).strftime("%Y-%m-%d"),
            "state": str(getattr(r, "state")),
            "area": str(getattr(r, "area")),
            "aqi": round(float(getattr(r, "aqi_value")), 1),
            "category": aqi_category(getattr(r, "aqi_value")),
            "source_status": str(getattr(r, "air_quality_status", "Unknown")),
            "pollutants": str(getattr(r, "prominent_pollutants", "Unknown")),
            "stations": int(getattr(r, "number_of_monitoring_stations")) if pd.notna(getattr(r, "number_of_monitoring_stations")) else None,
            "label_mismatch": bool(getattr(r, "status_mismatch", False)),
        })
    return out


def _error(message: str, status_code: int = 400):
    raise HTTPException(status_code=status_code, detail=message)


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def homepage():
    index_path = FRONTEND_DIR / "index.html"
    if not index_path.exists():
        _error("Frontend index.html not found.", 500)
    return index_path.read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    try:
        df = load_data()
        return {
            "status": "ok", "service": "environmental-risk-api", "version": app.version,
            "data_loaded": True, "rows": int(len(df)),
            "data_start": df["date"].min().strftime("%Y-%m-%d"),
            "data_end": df["date"].max().strftime("%Y-%m-%d"),
            "mode": "historical_dataset", "models_cached": len(registry.cache),
        }
    except Exception as exc:
        return JSONResponse(status_code=503, content={"status": "error", "message": str(exc)})


@app.get("/api/areas")
def areas(search: str = ""):
    df = load_data()
    items = get_area_records(df)
    query = search.strip().casefold()
    if query:
        items = [x for x in items if query in x["area"].casefold() or query in x["state"].casefold()]
    return {"count": len(items), "areas": items[:500]}


@app.get("/api/summary")
def summary(area: str = "Ahmedabad", state: str = "Gujarat"):
    df = load_data()
    try:
        selected = select_area(df, area, state)
    except ValueError as exc:
        _error(str(exc), 404)
    latest = selected.iloc[-1]
    all_dates = selected["date"].sort_values()
    expected_days = pd.date_range(all_dates.min(), all_dates.max(), freq="D")
    missing_days = len(expected_days.difference(pd.DatetimeIndex(all_dates.unique())))
    monthly = selected.assign(month=selected["date"].dt.to_period("M").astype(str)).groupby("month").agg(
        mean_aqi=("aqi_value", "mean"), median_aqi=("aqi_value", "median"), observations=("aqi_value", "count")
    ).reset_index().to_dict(orient="records")
    latest20 = selected.tail(30)["aqi_value"]
    return {
        "area": area, "state": state,
        "latest": {"date": latest["date"].strftime("%Y-%m-%d"), "aqi": round(float(latest["aqi_value"]), 1),
                   "category": aqi_category(latest["aqi_value"]), "source_status": str(latest["air_quality_status"]),
                   "pollutants": str(latest["prominent_pollutants"]), "stations": int(latest["number_of_monitoring_stations"]) if pd.notna(latest["number_of_monitoring_stations"]) else None},
        "observations": int(len(selected)), "period_start": selected["date"].min().strftime("%Y-%m-%d"),
        "period_end": selected["date"].max().strftime("%Y-%m-%d"), "calendar_gaps": int(missing_days),
        "mean_aqi": round(float(selected["aqi_value"].mean()), 2),
        "median_aqi": round(float(selected["aqi_value"].median()), 2),
        "min_aqi": round(float(selected["aqi_value"].min()), 1), "max_aqi": round(float(selected["aqi_value"].max()), 1),
        "std_aqi": round(float(selected["aqi_value"].std()), 2),
        "last_30_day_mean": round(float(latest20.mean()), 2),
        "last_30_day_change": round(float(latest20.iloc[-7:].mean() - latest20.iloc[:7].mean()), 2) if len(latest20) >= 14 else 0.0,
        "status_distribution": {str(k): int(v) for k, v in selected["category"].value_counts().items()},
        "monthly": [{"month": row["month"], "mean_aqi": round(float(row["mean_aqi"]), 2), "median_aqi": round(float(row["median_aqi"]), 2), "observations": int(row["observations"])} for row in monthly],
        "is_live": False, "notice": "Latest observation in the supplied historical dataset, not a live AQI reading.",
    }


@app.get("/api/history")
def history(area: str = "Ahmedabad", state: str = "Gujarat", days: int = Query(365, ge=0, le=4000)):
    df = load_data()
    try:
        selected = select_area(df, area, state)
    except ValueError as exc:
        _error(str(exc), 404)
    if days > 0:
        start = selected["date"].max() - pd.Timedelta(days=days - 1)
        selected = selected[selected["date"] >= start]
    records = _records(selected)
    monthly = selected.assign(month=selected["date"].dt.to_period("M").astype(str)).groupby("month").agg(
        mean_aqi=("aqi_value", "mean"), count=("aqi_value", "size")
    ).reset_index()
    return {"area": area, "state": state, "days_requested": days, "count": len(records), "records": records,
            "monthly": [{"month": r["month"], "mean_aqi": round(float(r["mean_aqi"]), 2), "count": int(r["count"])} for r in monthly.to_dict(orient="records")],
            "last_date": selected["date"].max().strftime("%Y-%m-%d")}


@app.get("/api/regions")
def regions(sort: str = Query("highest", pattern="^(highest|lowest|name)$"), limit: int = Query(25, ge=5, le=100), search: str = ""):
    df = load_data()
    latest = df.sort_values("date").groupby(["state", "area"], as_index=False).tail(1).copy()
    latest["category"] = latest["aqi_value"].map(aqi_category)
    query = search.strip().casefold()
    if query:
        latest = latest[latest["area"].str.casefold().str.contains(query, na=False) | latest["state"].str.casefold().str.contains(query, na=False)]
    if sort == "highest":
        latest = latest.sort_values("aqi_value", ascending=False)
    elif sort == "lowest":
        latest = latest.sort_values("aqi_value", ascending=True)
    else:
        latest = latest.sort_values(["state", "area"])
    results = []
    for r in latest.head(limit).itertuples(index=False):
        results.append({"state": str(r.state), "area": str(r.area), "aqi": round(float(r.aqi_value), 1),
                        "category": str(r.category), "date": r.date.strftime("%Y-%m-%d"),
                        "stations": int(r.number_of_monitoring_stations) if pd.notna(r.number_of_monitoring_stations) else None,
                        "pollutants": str(r.prominent_pollutants)})
    return {"count": len(results), "sort": sort, "as_of": df["date"].max().strftime("%Y-%m-%d"), "regions": results,
            "note": "Each area uses its latest available observation; dates can differ when source coverage differs."}


@app.get("/api/alerts")
def alerts(limit: int = Query(12, ge=1, le=50)):
    df = load_data()
    latest = df.sort_values("date").groupby(["state", "area"], as_index=False).tail(1).copy()
    latest["category"] = latest["aqi_value"].map(aqi_category)
    latest = latest.sort_values("aqi_value", ascending=False)
    out = []
    for r in latest[latest["aqi_value"] >= 151].head(limit).itertuples(index=False):
        aqi = float(r.aqi_value)
        if aqi > 200:
            severity = "high"
            message = "Elevated historical AQI in the latest available observation."
        else:
            severity = "medium"
            message = "AQI was above 150 in the latest available observation."
        out.append({"area": str(r.area), "state": str(r.state), "aqi": round(aqi, 1), "category": aqi_category(aqi),
                    "date": r.date.strftime("%Y-%m-%d"), "severity": severity, "message": message})
    return {"count": len(out), "alerts": out, "as_of": df["date"].max().strftime("%Y-%m-%d"), "is_live": False}


@app.get("/api/data-quality")
def quality(area: str = "Ahmedabad", state: str = "Gujarat"):
    df = load_data()
    summary = data_quality_summary(df)
    try:
        selected = select_area(df, area, state)
        full_dates = pd.date_range(selected["date"].min(), selected["date"].max(), freq="D")
        missing_dates = sorted(set(full_dates) - set(pd.DatetimeIndex(selected["date"].unique())))
        mismatch = selected[selected["status_mismatch"]]
        summary["selected_area"] = {"area": area, "state": state, "observations": int(len(selected)),
            "missing_calendar_dates": [d.strftime("%Y-%m-%d") for d in missing_dates],
            "category_mismatches": int(selected["status_mismatch"].sum()),
            "mismatch_samples": [{"date": r.date.strftime("%Y-%m-%d"), "aqi": float(r.aqi_value),
                                  "source_label": str(r.air_quality_status), "expected_label": str(r.expected_status)}
                                 for r in mismatch.head(20).itertuples(index=False)]}
    except ValueError:
        summary["selected_area"] = None
    return summary


@app.get("/api/models")
def models(area: str = "Ahmedabad", state: str = "Gujarat", retrain: bool = False):
    try:
        bundle = registry.train(area, state, force=retrain)
    except Exception as exc:
        _error(f"Model training failed: {exc}", 500)
    public = {k: v for k, v in bundle.items() if k not in ("production_model", "latest_series")}
    return public


@app.get("/api/forecast")
def forecast(area: str = "Ahmedabad", state: str = "Gujarat",
             horizon: int = Query(7, ge=1, le=14), scenario_pct: float = Query(0.0, ge=-15, le=15)):
    try:
        result = registry.forecast(area, state, horizon, scenario_pct)
    except Exception as exc:
        _error(f"Forecast could not be generated: {exc}", 500)
    return result


@app.get("/api/export")
def export_data(area: str = "Ahmedabad", state: str = "Gujarat", days: int = Query(0, ge=0, le=4000)):
    df = load_data()
    try:
        selected = select_area(df, area, state)
    except ValueError as exc:
        _error(str(exc), 404)
    if days:
        selected = selected[selected["date"] >= selected["date"].max() - pd.Timedelta(days=days - 1)]
    cols = ["date", "state", "area", "aqi_value", "air_quality_status", "expected_status", "prominent_pollutants", "number_of_monitoring_stations", "status_mismatch"]
    buffer = StringIO()
    selected[cols].to_csv(buffer, index=False, date_format="%Y-%m-%d")
    buffer.seek(0)
    safe_area = "".join(ch.lower() if ch.isalnum() else "_" for ch in area).strip("_")
    headers = {"Content-Disposition": f"attachment; filename={safe_area}_aqi_history.csv"}
    from fastapi.responses import Response
    return Response(content=buffer.getvalue(), media_type="text/csv; charset=utf-8", headers=headers)


@app.get("/api/overview")
def overview():
    """Small startup payload for the frontend shell."""
    df = load_data()
    return {"rows": int(len(df)), "states": int(df["state"].nunique()),
            "areas": int(df[["state", "area"]].drop_duplicates().shape[0]),
            "data_start": df["date"].min().strftime("%Y-%m-%d"),
            "data_end": df["date"].max().strftime("%Y-%m-%d"),
            "default_area": {"area": "Ahmedabad", "state": "Gujarat"},
            "mode": "historical_dataset"}
