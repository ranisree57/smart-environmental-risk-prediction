"""Time-aware feature engineering and model evaluation/forecasting."""
from __future__ import annotations

from datetime import timedelta
from functools import lru_cache
from pathlib import Path
import json
import math
import re
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from joblib import dump

from .config import MODELS_DIR, REPORTS_DIR
from .data_service import load_data, select_area, aqi_category

LAGS = [1, 2, 3, 7, 14, 30]
FEATURES = [f"lag_{i}" for i in LAGS] + ["roll_mean_7", "roll_mean_14", "roll_std_7", "month_sin", "month_cos", "dow_sin", "dow_cos", "doy_sin", "doy_cos"]


def _date_features(date: pd.Timestamp) -> dict[str, float]:
    day_of_year = date.dayofyear
    dow = date.dayofweek
    month = date.month
    return {
        "month_sin": math.sin(2 * math.pi * month / 12),
        "month_cos": math.cos(2 * math.pi * month / 12),
        "dow_sin": math.sin(2 * math.pi * dow / 7),
        "dow_cos": math.cos(2 * math.pi * dow / 7),
        "doy_sin": math.sin(2 * math.pi * day_of_year / 365.25),
        "doy_cos": math.cos(2 * math.pi * day_of_year / 365.25),
    }


def make_feature_table(area_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Use only past observed AQI for each target date; leave missing calendar observations missing."""
    ordered = area_df.sort_values("date").drop_duplicates("date", keep="last")
    series = ordered.set_index("date")["aqi_value"].astype(float).asfreq("D")
    x = pd.DataFrame(index=series.index)
    for lag in LAGS:
        x[f"lag_{lag}"] = series.shift(lag)
    prior = series.shift(1)
    x["roll_mean_7"] = prior.rolling(7, min_periods=5).mean()
    x["roll_mean_14"] = prior.rolling(14, min_periods=10).mean()
    x["roll_std_7"] = prior.rolling(7, min_periods=5).std().fillna(0.0)
    date_df = pd.DataFrame([_date_features(d) for d in x.index], index=x.index)
    x = pd.concat([x, date_df], axis=1)
    y = series.rename("target_aqi")
    valid = x.notna().all(axis=1) & y.notna()
    return x.loc[valid, FEATURES], y.loc[valid]


def _metrics(y_true, y_pred) -> dict[str, float | None]:
    return {
        "mae": round(float(mean_absolute_error(y_true, y_pred)), 3),
        "rmse": round(float(np.sqrt(mean_squared_error(y_true, y_pred))), 3),
        "r2": round(float(r2_score(y_true, y_pred)), 4) if len(y_true) > 1 else None,
    }


def _model_factories() -> dict[str, tuple[str, Any]]:
    return {
        "Ridge Regression": ("regularized_linear", lambda: Ridge(alpha=8.0)),
        "Random Forest": ("tree_ensemble", lambda: RandomForestRegressor(
            n_estimators=180, max_depth=10, min_samples_leaf=3, random_state=42, n_jobs=-1
        )),
        "Gradient Boosting": ("boosted_trees", lambda: HistGradientBoostingRegressor(
            max_iter=160, learning_rate=0.06, max_leaf_nodes=15, l2_regularization=1.0,
            random_state=42
        )),
    }


class ModelRegistry:
    def __init__(self):
        self.cache: dict[str, dict[str, Any]] = {}

    @staticmethod
    def key(area: str, state: str) -> str:
        return f"{state.strip().casefold()}::{area.strip().casefold()}"

    def train(self, area: str = "Ahmedabad", state: str = "Gujarat", force: bool = False) -> dict[str, Any]:
        key = self.key(area, state)
        if key in self.cache and not force:
            return self.cache[key]
        df = load_data()
        area_df = select_area(df, area, state)
        X, y = make_feature_table(area_df)
        if len(X) < 120:
            raise ValueError(f"Not enough usable daily records to train for {area}. Found {len(X)} after lag creation; need at least 120.")

        n = len(X)
        train_end = int(n * 0.70)
        val_end = int(n * 0.85)
        if train_end < 60 or val_end <= train_end or val_end >= n:
            raise ValueError("Not enough records for chronological train/validation/test splits.")
        X_train, y_train = X.iloc[:train_end], y.iloc[:train_end]
        X_val, y_val = X.iloc[train_end:val_end], y.iloc[train_end:val_end]
        X_test, y_test = X.iloc[val_end:], y.iloc[val_end:]

        candidates = []
        best = None
        for name, (model_type, factory) in _model_factories().items():
            estimator = factory()
            estimator.fit(X_train, y_train)
            pred_val = np.clip(estimator.predict(X_val), 0, 500)
            score = _metrics(y_val, pred_val)
            row = {"name": name, "model_type": model_type, "validation": score}
            candidates.append(row)
            if best is None or score["mae"] < best["validation"]["mae"]:
                best = {"name": name, "model_type": model_type, "validation": score, "estimator": estimator}

        # The reported test period is untouched while model choice is made using validation MAE.
        test_pred = np.clip(best["estimator"].predict(X_test), 0, 500)
        baseline_pred = np.clip(X_test["lag_1"].to_numpy(), 0, 500)
        selected_test = _metrics(y_test, test_pred)
        baseline_test = _metrics(y_test, baseline_pred)

        # Refit the selected family on all valid historical examples for post-period forecasting.
        factory = _model_factories()[best["name"]][1]
        production_model = factory()
        production_model.fit(X, y)
        if hasattr(production_model, "feature_importances_"):
            raw_importance = np.asarray(production_model.feature_importances_, dtype=float)
        elif hasattr(production_model, "coef_"):
            raw_importance = np.abs(np.asarray(production_model.coef_, dtype=float))
        else:
            raw_importance = np.zeros(len(FEATURES), dtype=float)
        importance_total = float(raw_importance.sum())
        if importance_total > 0:
            raw_importance = raw_importance / importance_total
        feature_importance = [{"feature": feature, "importance": round(float(weight), 4)}
                              for feature, weight in sorted(zip(FEATURES, raw_importance), key=lambda item: item[1], reverse=True)]
        val_pred = np.clip(best["estimator"].predict(X_val), 0, 500)
        residuals = (y_val.to_numpy() - val_pred).astype(float)
        resid_q10, resid_q90 = np.quantile(residuals, [0.10, 0.90]).tolist()
        training_end = X_train.index.max().strftime("%Y-%m-%d")
        validation_end = X_val.index.max().strftime("%Y-%m-%d")
        test_start = X_test.index.min().strftime("%Y-%m-%d")
        test_end = X_test.index.max().strftime("%Y-%m-%d")
        latest_observation = area_df["date"].max().strftime("%Y-%m-%d")

        def serialize_model_type(model_type: str):
            return model_type

        model_slug = re.sub(r"[^a-z0-9]+", "_", f"{state}_{area}".lower()).strip("_")
        model_path = MODELS_DIR / f"{model_slug}_forecast.joblib"
        dump({"model": production_model, "features": FEATURES, "model_name": best["name"], "area": area, "state": state}, model_path)

        result = {
            "area": area, "state": state,
            "model_name": best["name"], "model_type": best["model_type"],
            "trained_at": pd.Timestamp.now().isoformat(timespec="seconds"),
            "latest_observation": latest_observation,
            "usable_rows": int(n),
            "split": {"train_rows": int(len(X_train)), "validation_rows": int(len(X_val)), "test_rows": int(len(X_test)),
                      "train_end": training_end, "validation_end": validation_end, "test_start": test_start, "test_end": test_end},
            "validation_models": candidates,
            "test_metrics": {"selected_model": selected_test, "persistence_baseline": baseline_test,
                             "mae_improvement_percent": round((baseline_test["mae"] - selected_test["mae"]) / baseline_test["mae"] * 100, 2) if baseline_test["mae"] else 0},
            "features": FEATURES,
            "feature_importance": feature_importance,
            "residual_quantiles": {"q10": float(resid_q10), "q90": float(resid_q90)},
            "model_path": str(model_path.relative_to(MODELS_DIR.parent)).replace("\\", "/"),
            "production_model": production_model,
            "latest_series": area_df[["date", "aqi_value"]].copy(),
        }
        self.cache[key] = result

        # Save a clean, human-readable metrics report without model objects or raw series.
        public = {k: v for k, v in result.items() if k not in ("production_model", "latest_series")}
        report_path = REPORTS_DIR / f"{model_slug}_model_report.json"
        report_path.write_text(json.dumps(public, indent=2, default=str), encoding="utf-8")
        return result

    def status(self, area: str = "Ahmedabad", state: str = "Gujarat") -> dict[str, Any]:
        bundle = self.cache.get(self.key(area, state))
        if not bundle:
            return {"trained": False, "area": area, "state": state, "message": "Model training starts when you open Model Bench or Forecast Lab."}
        return {"trained": True, "area": area, "state": state, "model_name": bundle["model_name"],
                "trained_at": bundle["trained_at"], "latest_observation": bundle["latest_observation"],
                "test_metrics": bundle["test_metrics"]}

    def forecast(self, area: str, state: str, horizon: int, scenario_pct: float = 0.0) -> dict[str, Any]:
        bundle = self.train(area, state)
        area_df = bundle["latest_series"]
        actual_series = area_df.drop_duplicates("date", keep="last").set_index("date")["aqi_value"].astype(float).sort_index()
        last_date = pd.Timestamp(actual_series.index.max())
        lookup = {pd.Timestamp(k).normalize(): float(v) for k, v in actual_series.items()}
        model = bundle["production_model"]
        rows = []
        for step in range(1, horizon + 1):
            target_date = last_date + pd.Timedelta(days=step)
            feature: dict[str, float] = {}
            missing_lags = []
            for lag in LAGS:
                value = lookup.get((target_date - pd.Timedelta(days=lag)).normalize())
                if value is None or not np.isfinite(value):
                    missing_lags.append(lag)
                feature[f"lag_{lag}"] = value if value is not None else np.nan
            last7 = [lookup.get((target_date - pd.Timedelta(days=i)).normalize(), np.nan) for i in range(1, 8)]
            last14 = [lookup.get((target_date - pd.Timedelta(days=i)).normalize(), np.nan) for i in range(1, 15)]
            valid7 = np.asarray([x for x in last7 if np.isfinite(x)], dtype=float)
            valid14 = np.asarray([x for x in last14 if np.isfinite(x)], dtype=float)
            feature["roll_mean_7"] = float(np.mean(valid7)) if len(valid7) >= 5 else np.nan
            feature["roll_mean_14"] = float(np.mean(valid14)) if len(valid14) >= 10 else np.nan
            feature["roll_std_7"] = float(np.std(valid7, ddof=1)) if len(valid7) >= 5 else np.nan
            feature.update(_date_features(target_date))
            if any(not np.isfinite(feature.get(f)) for f in FEATURES):
                raise ValueError("The latest history has too many missing days for this forecast. Try an area with more complete recent observations.")
            Xrow = pd.DataFrame([[feature[f] for f in FEATURES]], columns=FEATURES)
            raw_prediction = float(np.clip(model.predict(Xrow)[0], 0, 500))
            scenario_prediction = float(np.clip(raw_prediction * (1.0 + scenario_pct / 100.0), 0, 500))
            spread = max(8.0, (abs(bundle["residual_quantiles"]["q90"] - bundle["residual_quantiles"]["q10"]) / 2) * math.sqrt(step))
            low = float(np.clip(scenario_prediction - spread, 0, 500))
            high = float(np.clip(scenario_prediction + spread, 0, 500))
            rows.append({
                "date": target_date.strftime("%Y-%m-%d"), "step": step,
                "predicted_aqi": round(scenario_prediction, 1), "model_aqi": round(raw_prediction, 1),
                "lower_estimate": round(low, 1), "upper_estimate": round(high, 1),
                "category": aqi_category(scenario_prediction), "scenario_pct": float(scenario_pct),
                "confidence_note": "Indicative interval based on validation residuals; not a formal guarantee."
            })
            # Recursive forecast: prediction is only used for future lags; no future actuals are used.
            lookup[target_date.normalize()] = scenario_prediction
        return {
            "area": area, "state": state, "model_name": bundle["model_name"],
            "source_last_observation": last_date.strftime("%Y-%m-%d"),
            "forecast_start": rows[0]["date"], "forecast_end": rows[-1]["date"],
            "horizon": horizon, "scenario_pct": float(scenario_pct),
            "is_live": False,
            "note": "This is a retrospective demonstration forecast beyond the dataset's last observation. It is not a current AQI reading or a live meteorological forecast.",
            "metrics": bundle["test_metrics"], "forecast": rows,
        }


registry = ModelRegistry()
