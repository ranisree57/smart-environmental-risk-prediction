"""Smart Environmental Risk Prediction backend package."""
