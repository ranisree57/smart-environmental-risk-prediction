from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
REPORTS_DIR = ROOT_DIR / "reports"
MODELS_DIR = ROOT_DIR / "models"
FRONTEND_DIR = ROOT_DIR / "frontend"
ASSETS_DIR = FRONTEND_DIR / "assets"
DATA_ZIP = RAW_DIR / "archive (1).zip"

for _path in (PROCESSED_DIR, REPORTS_DIR, MODELS_DIR):
    _path.mkdir(parents=True, exist_ok=True)
