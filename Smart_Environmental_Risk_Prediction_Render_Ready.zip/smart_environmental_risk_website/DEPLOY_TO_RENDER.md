# Publish AERO and share a public website link

The address `http://127.0.0.1:8000` is local to your own computer. To share the website with your professor/classmates, deploy it to a hosting service such as Render.

## 1. Upload the project to GitHub

1. Extract this ZIP.
2. Open the inner folder `smart_environmental_risk_website` (the folder containing `app`, `frontend`, `requirements.txt`, `.python-version`, and `render.yaml`).
3. Create a new GitHub repository. You may keep it private if your goal is only to share the deployed website URL. Confirm dataset license/attribution first if you choose a public repository.
4. Push/upload the *contents of this inner folder* to the repository root. Do not upload the outer wrapper folder as the only top-level item.
5. Ensure these files appear at the repository root: `app/`, `frontend/`, `data/`, `requirements.txt`, `.python-version`, and `render.yaml`.

## 2. Deploy on Render

Recommended: use Render's Blueprint flow so the included `render.yaml` supplies the commands.

1. Sign in to Render and connect/authorize your GitHub account.
2. Choose **New +** → **Blueprint** (or use **New +** → **Web Service** and configure the commands manually).
3. Select the repository and branch that contains the files above.
4. If configuring a Web Service manually, select runtime **Python 3** and use:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
   - Python version: `3.13.5` (also pinned in `.python-version`)
   - Instance plan: Free for a no-cost demonstration, where available.
5. Start deployment and watch the build/deploy logs. Resolve any build error before sharing the URL.
6. When deployment succeeds, Render shows a public URL similar to `https://your-service-name.onrender.com`. Share that URL with your professor/classmates.

## 3. Verify before sharing

Open the public root URL, then check:
- `/api/health`
- `/api/docs`
- the forecast lab and model comparison in the UI

The app is designed for historical AQI data. Included records end on 2025-04-30; do not describe forecasts as live readings.

## Free-hosting notes

Free Render web services can spin down after inactivity and take around a minute to wake up on the next request. Keep this in mind during a live seminar. The project is a student demonstration, not a production monitoring service.

Official guide: https://render.com/docs/deploy-fastapi
